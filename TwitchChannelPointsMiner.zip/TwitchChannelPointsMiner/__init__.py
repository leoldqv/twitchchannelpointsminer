# -*- coding: utf-8 -*-
__version__ = "1.9.5"
from .TwitchChannelPointsMiner import TwitchChannelPointsMiner

__all__ = [
    "TwitchChannelPointsMiner",
]
